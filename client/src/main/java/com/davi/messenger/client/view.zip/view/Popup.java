package com.davi.messenger.client.view;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.ScrollPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Popup extends JFrame {
	private static final long serialVersionUID = 1L;

	// Tamanho da janela
	private final int WIDTH = 600;
	private final int HEIGHT = 400;

	// Componentes da janela
	private JButton add_button;
	private JButton clean_button;
	//private JPanel panelAlunos;
	private JTextField textFieldMessage;
	private JTextField textFieldName;

	// Lista que contem a lista de components para cada aluno
	private ArrayList<ViewUser> lista = new ArrayList<>();

	public Popup() {
		// Define as caracteristicas da janela (JFrame)
		setTitle("MVC - Messager");
		setSize(WIDTH, HEIGHT);
		setPreferredSize(getSize());
		setLayout(new FlowLayout());
		setResizable(false);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// Define e carrega os componentes da janela
		init();

		// Torna a janela vis�vel
		setVisible(true);
	}

	// Define e adiciona os componentes do JFrame
	private void init() {
		add_button = new JButton("Add Message");

		clean_button = new JButton("Clear");
		clean_button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				clear();
			}
		});

		textFieldMessage = new JTextField();
		textFieldMessage.setPreferredSize(new Dimension(100, 20));
		textFieldName = new JTextField();
		textFieldName.setPreferredSize(new Dimension(300, 20));

        /* 
		panelAlunos = new JPanel();
		panelAlunos.setPreferredSize(new Dimension(200, 200));
		panelAlunos.setLayout(new FlowLayout());

		ScrollPane scrollPane = new ScrollPane();
		scrollPane.setPreferredSize(new Dimension((int) getSize().getWidth() - 10, 200));
		scrollPane.add(panelAlunos);
        */

		//add(scrollPane);

		add(new JLabel("Message"));
		//add(textFieldMessage);
		add(new JLabel("Name"));
		add(textFieldName);
		add(add_button);
		add(clean_button);
	}

	// Cria um JOptionPane com uma mensagem
	public void showMessage(String message) {
		JOptionPane.showMessageDialog(getParent(), message);
	}
	
	// Limpa os dados do formul�rio
	public void clear() {
		textFieldMessage.setText("");
		textFieldName.setText("");
	}

	// Adiciona um escutador para o botao de inserir aluno
	public void addListenerAddButton(ActionListener listener) {

		for (ActionListener al : add_button.getActionListeners()) {
			add_button.removeActionListener(al);
		}

		add_button.addActionListener(listener);
	}

	// Getters and Setters
	public String getNameAluno() {
		return textFieldName.getText().toString();
	}

    /* 
	public int getMatricula() throws NumberFormatException {
		return Integer.parseInt(textFieldMatricula.getText().toString());
	}
    */
	public JButton getBotaoAdicionar() {
		return add_button;
	}
    /* 
	public JPanel getPanelAlunos() {
		return panelAlunos;
	}
    */
	public ArrayList<ViewUser> getComponentList() {
		return lista;
	}
}
