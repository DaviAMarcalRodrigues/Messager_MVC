package com.davi.messenger.client.view;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class ViewUser extends JPanel{
	
	private static final long serialVersionUID = 2L;
	
	private JTextField label_User;
	private JTextField label_message;
	
	private JButton button_send;
	private JButton button_exclude;
	 
	public ViewUser(String user, String message) {
		
		setLayout(new FlowLayout());

		label_User = new JTextField("User: ");
		label_message = new JTextField("Message: ");
		
		button_send = new JButton("Send");
		button_exclude = new JButton("Exclude");
		
		
		label_User.setPreferredSize(new Dimension(80, 20));
		label_message.setPreferredSize(new Dimension(250, 20));
	
		add(label_User);
		add(label_message);
		add(button_send);
		add(button_exclude);
		
		label_User.setEnabled(false);
		label_message.setEnabled(false);
	}
	
	public JTextField getLabel_User() {
		return label_User;
	}

	public JTextField getLabel_message() {
		return label_message;
	}

	public void addListenerSendButton(ActionListener listener) {
		
		for( ActionListener al : button_send.getActionListeners() ) {
			button_send.removeActionListener( al );
	    }
		
		this.button_send.addActionListener(listener);
	}

	public void addListenerExcludeButton(ActionListener listener) {
		
		for( ActionListener al : button_send.getActionListeners() ) {
			button_send.removeActionListener( al );
	    }
		
		this.button_send.addActionListener(listener);
	}
	
	// Ativa ou desativa os formularios
	public void setEnableComponents(boolean value) {
		label_User.setEnabled(value);
		label_message.setEnabled(value);
	}

	public JButton getButtonSend() {
		return button_send;
	}
	
}
