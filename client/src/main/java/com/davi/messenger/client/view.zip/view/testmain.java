package com.davi.messenger.client.view;

public class testmain extends Popup implements ViewUser{
    static ViewUser viewUser;

    static void main(String[] args) {
        viewUser = new ViewUser("123", "John Doe");
        viewUser.setEnableComponents(true);
        viewUser.getLabel_User().setText("User: John Doe");
        viewUser.getLabel_message().setText("Message: Hello, World!");
        viewUser.addListenerSendButton(e -> {
            String user = viewUser.getLabel_User().getText();
            String message = viewUser.getLabel_message().getText();
            System.out.println("Sending message from " + user + ": " + message);
        });

        Popup popup = new Popup();
        popup.getComponentList().add(viewUser);
        popup.getBotaoAdicionar().addActionListener(e -> {
            String user = viewUser.getLabel_User().getText();
            String message = viewUser.getLabel_message().getText();
            System.out.println("Adding user " + user + " with message: " + message);
        });

    }
}
